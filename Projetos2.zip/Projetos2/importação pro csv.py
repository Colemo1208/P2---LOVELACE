import pandas as pd
url1 ='https://www.maiscelular.com.br/fichas-tecnicas/xiaomi/17/'
htmlteste = pd.read_html(url1)

df = pd.DataFrame(htmlteste[0])
print(df)
df.to_csv('teste.csv')