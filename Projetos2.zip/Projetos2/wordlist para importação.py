import requests
from bs4 import BeautifulSoup
num_inicial = 1
num_final = 149

url = 'https://www.maiscelular.com.br/fichas-tecnicas/?aparelho=1&z={}#google_vignette'.format(num_inicial)

page = requests.get(url)

soup = BeautifulSoup(page.text,features="lxml")

pegar_link = soup.find('a',class_= 'col-md-6 col-lg-6 bl1').text

def Imprimir(char_link):
    return char_link pegar_link is not None == pegar_link
    else return 0

print(Imprimir)

